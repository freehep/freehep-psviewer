		    LICENSE AGREEMENT
		    ======= =========
 
Opening the package containing this collection of software constitutes
your agreement to abide by the quite reasonable terms of this
license agreement, and to the terms of the Disclaimer (see below)
included with this collection of software.

The collection of software covered by this license agreement is
copyrighted by Trilithon Software.



	        SHAREWARE STATEMENT
	        ========= =========

This software is not free.  It is designated as shareware.  If you
like this software and decide it is of value to you, you are
requested to send a cheque or money order in the amount that you
deem the software to be worth.  A reasonable suggested value for
this collection is $20.00 US.




	    WHAT YOU MAY DO WITH THIS SOFTWARE
	    ==== === === == ==== ==== ========

You may use this software for your own personal use, to experiment,
play, learn (are play and learn the same thing?), or impress your
friends with all the cool things you can do with PostScript. But
see later for Containing Software.

You may use this software on one computer system only.  If you wish
to use this software on more than one computer system at a time,
you must obtain one copy per computer system.

Say you own a Macintosh and purchase a copy of this software package
to learn more about PostScript. In your persona as the Macintosh
hacker, you have fun with this software.

When you wish to use this software on your (shudder!) PC/DOS
computer, you must purchase a separate copy of the software, because
you're another persona when you use your PC/DOS computer.  This
rule is analogous to that of a book:  you can only have one copy
of it, but it can be in one of several places.  That is, you would
be licensed to use it in only one computer at a time, but it can
be resident on more than one. If ever there could be two users,
you need two license agreements.

You may make a reasonable number of copies of this software for
backup purposes.

Reasonable, in this context, means maybe one or two backup copies,
and certainly no more than ten copies, so you can restore the
contents of this software package in the event of disk crashes or
other kinds of destruction.

Unreasonable is (say) more than ten copies of the software, which
would indicate either paranoia or an intent to deviate from the
spirit of this license agreement, and would constitute a felony
under federal copyright law anyway.



        Containing Software
        ========== ========

You may use this software as part of your
own applications, which you may then use for your own purposes sell
for your profit, and so on. If you do use all or parts of this
software for future products, you must indicate clearly that parts
of your product contain software obtained from and copyright
Trilithon Software.

The intent is simple, so let's use an example. Chapter 14 contains
a miserably simple error handler. If you wish to use this miserably
simple error handler as the basis for an all singing and dancing
error handler of your own in hopes of earning megasimoleons from
the proceeds, have at it, but your code must indicate clearly that
the basis of your fabulous error handler came from ideas you obtained
from Trilithon Software.




	    WHAT YOU MAY NOT DO WITH THIS SOFTWARE
	    ==== === === === == ==== ==== ========

You may not sell, lease, rent, or sublicense this collection of
software to any other person or institution.

You may not give a copy of this software to anybody else unless they
intend to pay the shareware fee at some point.  If your
friend(s) are impressed by this software and would like their own
copy, they should send in the shareware fee as listed above.

You may not publish this software for profit or claim it as your
own creation.





	               DISCLAIMER
	               ==========

The increasingly litigious nature of our society requires us to
place this DISCLAIMER into this collection of postScript software.

o   The authors are not responsible for the consequences of
    use of this software, no matter how awful, even if such
    awful consequences arise from flaws in this software.

o   The origin of this software must not be misrepresented,
    either by explicit claim or by omission.

o   Altered versions must be plainly marked as such, and must
    not be misrepresented as being the original software.

o   This notice may not be removed or altered.

o   Please read the above license agreement.
